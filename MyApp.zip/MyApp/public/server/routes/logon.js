var express = require('express');
var router = express.Router();
const bodyParser = require('body-parser');
const loggingRouter=express.Router();
loggingRouter.use(bodyParser.json())

const url = 'mongodb://localhost:27017/';
const dbname = 'usersdb';


loggingRouter.route('/')
.all((req,res,next)=>{
    console.log(req,url);
    console.log(req.headers);
    res.statusCode=200;
    res.setHeader('Content-Type','text/html');
    next()

})
  
.get((req,res,next)=>{
  console.log('Got here')
  res.render('new_user')
})

.post((req,res,next)=>{
MongoClient.connect(url).then((client) => {

    console.log('Connected correctly to server');
    const db = client.db(dbname);
    const obj=JSON.parse(JSON.stringify(req.body));
    console.log(obj)

    dboper.insertDocument(db,obj,
      "users")
      .then((result)=>{
        console.log("Insert Document:\n", result.ops);
        res.render('success',{usr:obj})
      }).catch((err) => console.log(err));
      client.close;
  }).catch((err)=>console.log(err));
})
    
.put((req,res,next)=>{
  res.statusCode=403;
  res.end('put operation not supported:'+req.body.username+''+req.body.password);
  })

.delete((req,res,next)=>{
  res.end('delete all users')

});

loggingRouter.route('/showall')
.all((req,res,next)=>{
  console.log(req.url);
  console.log(req.headers);
  res.statusCode=200;
  res.setHeader('Content-Type','text/html');
  next()
 })

.get((req,res,next)=>{
  console.log("Get here")
  console.log("Get here")


  MongoClient.connect(url),then((client) => {

    console.log('Connected correctly to server');
    const db = client.db(dbname);
  
    dboper.findDocuments(db,"users")
    .then((result)=>{
      console.log("Found users:\n", result);
      res.render('showall',{links:result})
    }).catch((err)=> console.log(err));
    client.close;
}).catch((err)=>console.log(err));

}) 
  


/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('logon', { title: 'Logging on' });
});

router.post('/', function(req, res, next) {
  console.log(req.body)
  res.render('logged', { title: 'Logged on' });
});


module.exports = router;
