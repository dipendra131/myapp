var express = require('express'); 
var router = express.Router();
var passport = require('passport');
var gravatar = require('gravatar');
/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});
router.get('/logon', function(req, res, next) {
  res.render('logon', { title: 'Logging on' });
});

 /* GET Logout Page */ 
router.get('/logout', function(req, res) { 
req.logout(); 
res.redirect('/'); 
}); 



module.exports = router;
