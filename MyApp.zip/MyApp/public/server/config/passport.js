// load passport module 
var LocalStrategy    = require('passport-local').Strategy; 
// load up the user model 
var User = require('../routes/users'); 

module.exports = function(passport) { 
    // passport init setup 
    // serialize the user for the session 
    passport.serializeUser(function(user, done) { 
        done(null, user.id); 
    }); 
    //       deserialize the user 
    passport.deserializeUser(function(id, done) { 
        User.findById(id, function(err, user) { 
            done(err, user); 
        }); 
    }); 
    // using local strategy 
    passport.use('local-logon', new LocalStrategy({ 
        // change default username and password, to email 
        //and password 
        usernameField : 'username', 
        passwordField : 'password', 
        passReqToCallback : true 
    }, 
    function(req, username, password, done) { 
        if (username) 
        // format to lower-case 
        username = username.toLowerCase(); 
        // process asynchronous 
        process.nextTick(function() { 
            User.findOne({ 'local.username' :  username }, 
             function(err, user)
          { 
            // if errors 
           if (err) 
             return done(err); 
           // check errors and bring the messages 
           if (!user) 
             return done(null, false, req.flash('loginMessage',
             'No user found.')); 
          if (!user.validPassword(password)) 
            return done(null, false, req.flash('loginMessage',
            'Wohh! Wrong password.')); 
          // everything ok, get user 
          else 
            return done(null, user); 
          }); 
        }); 
     })); 
   
}; 