 // Database URL 
module.exports = { 
    // Connect with MongoDB on local machine 
    'url' : 'mongodb://localhost/mvc-app' 
}; 