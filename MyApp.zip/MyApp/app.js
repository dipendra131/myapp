var createError = require('http-errors');
var path = require('path');
var express = require("express");
var cookieParser = require('cookie-parser');
var logger = require('morgan');

var indexRouter = require('./public/server/routes/index');
var usersRouter = require('./public/server/routes/users');
var logonRouter = require('./public/server/routes/logon');


var app = express(); 
//view engine setup
app.set('views', path.join(__dirname,'views'));
app.set("view engine", "ejs"); 

app.use(logger('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, 'public')));

app.use('/', indexRouter);
app.use('/users', usersRouter);
app.use('/logon',logonRouter);

app.get("/", function (req, res) { 
     res.render("index"); 
 }); 
app.get("/logon", function (req, res) { 
     res.render("logon"); 
 });
 //Handling user login 
//app.post("/logon", passport.authenticate("local", { 
  //   successRedirect: "/logged", 
    // failureRedirect: "/logon"
 //}), function (req, res) { 
// }); 
app.get("/logged", isLoggedIn, function (req, res) { 
     res.render("logged"); 
 }); 
app.get("/about", function (req, res) { 
     res.render("about"); 
 }); 
app.get("/contact", function (req, res) { 
     res.render("contact"); 
 }); 
app.get("/help", function (req, res) { 
     res.render("help"); 
 }); 
function isLoggedIn(req, res, next) { 
     if (req.isAuthenticated()) 
       return next(); 
     res.redirect('/logon'); 
       } 
//Handling user logout  
app.get("/logout", function (req, res) { 
     req.logout(); 
     res.redirect("/");
});


module.exports = app;
